ダウンロード
django 
channels
channels_redis


docker コマンド　
docker run -p 6379:6379 -d redis:5


projectpost/views.py 40~43行が実行場所
